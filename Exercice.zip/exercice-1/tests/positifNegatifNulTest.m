
setTestsUp
try
    inputOut = [3, 2.7, -4, -12.5, 0];
    
    positifNegatifNul
    validateStdin('positif')
    
    positifNegatifNul
    validateStdin('positif')
    
    positifNegatifNul
    validateStdin('n gatif')
    
    positifNegatifNul
    validateStdin('n gatif')
    
    positifNegatifNul
    validateStdin('nul')
    
catch ME
    setTestsDown
    throw(ME)
end

setTestsDown