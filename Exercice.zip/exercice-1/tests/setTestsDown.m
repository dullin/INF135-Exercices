clearvars -global printedText inputOut
clear input iInput
rmpath('stubs')
rmpath('../etudiant')
warning('on','MATLAB:dispatcher:nameConflict')