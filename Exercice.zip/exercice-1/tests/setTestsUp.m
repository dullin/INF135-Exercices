clearvars -global printedText
global inputOut
warning('off','MATLAB:dispatcher:nameConflict')
addpath('stubs')
addpath('../etudiant')