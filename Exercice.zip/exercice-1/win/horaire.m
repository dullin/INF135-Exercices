% Affiche l'horaire suivant dans le fen�tre de commande: 
%
% Example:
%   ::
%
%       >> horaire
%       Horaire:
%       7h00 � d�jeuner
%       12h00 � diner
%       17h00 � souper
%          
%

% Vide la fen�tre de commande.
clc

% Affiche l'horaire.
fprintf('Horaire:\n')
fprintf('7h00 - d�jeuner\n')
fprintf('12h00 - diner\n')
fprintf('17h00 - souper\n')
