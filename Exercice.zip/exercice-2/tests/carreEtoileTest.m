
setTestsUp
try
    inputOut = 5;
    carreEtoile
    validateStdin('*****');
catch ME
    setTestsDown
    throw(ME)
end

setTestsDown