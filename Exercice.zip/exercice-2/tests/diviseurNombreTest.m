
setTestsUp
try
    inputOut = [14, 45, 12, 1];
    diviseurNombre
    validateStdin('1 2 7 14');
    diviseurNombre
    validateStdin('1 3 5 9 15 45');
    diviseurNombre
    validateStdin('1 2 3 4 6 12');
    diviseurNombre
    validateStdin('1');
catch ME
    setTestsDown
    throw(ME)
end

setTestsDown