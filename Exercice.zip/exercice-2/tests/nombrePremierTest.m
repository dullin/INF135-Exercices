
setTestsUp
try
    inputOut = 18;
    nombrePremier
    validateStdin('18 n''est pas premier');
catch ME
    setTestsDown
    throw(ME)
end

setTestsDown