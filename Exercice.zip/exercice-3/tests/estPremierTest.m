assert(estPremier(18) == false)
assert(estPremier(47) == true)