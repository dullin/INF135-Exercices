assert(inverseAdditif(34) == -34)
assert(inverseAdditif(-18) == 18)