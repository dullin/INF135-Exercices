assert(maximumDeDeux(3, 3) == 3)
assert(maximumDeDeux(4, 8) == 8)
assert(maximumDeDeux(12, 25) == 25)