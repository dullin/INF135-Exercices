assert(maximumDeQuatre(3, 3, 3, 3) == 3)
assert(maximumDeQuatre(2, 4, 8, 5) == 8)
assert(maximumDeQuatre(12, 1, 25, 6) == 25)