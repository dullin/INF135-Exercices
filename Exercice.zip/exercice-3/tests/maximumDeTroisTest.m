assert(maximumDeTrois(3, 3, 3) == 3)
assert(maximumDeTrois(4, 8, 5) == 8)
assert(maximumDeTrois(12, 25, 6) == 25)