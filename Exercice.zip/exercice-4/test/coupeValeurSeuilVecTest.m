assert(isequal(coupeValeurSeuilVec([34, 23, 12, 20], 20), [12, 20]))
assert(isequal(coupeValeurSeuilVec([4, 6, 10, 15], 30), [4, 6, 10, 15]))
