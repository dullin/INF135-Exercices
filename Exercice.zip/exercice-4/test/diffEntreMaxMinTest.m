assert(diffEntreMaxMin([45, 35, 40, 37]) == 10)
assert(diffEntreMaxMin([1, 2, 3, 4, 5]) == 4)