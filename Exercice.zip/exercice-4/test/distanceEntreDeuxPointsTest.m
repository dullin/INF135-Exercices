assert(abs(distanceEntreDeuxPoints([6, 2], [1, 4]) - 5.385164) < 0.01)
assert(abs(distanceEntreDeuxPoints([12, 5], [33, 2]) - 21.2132) < 0.01)
