assert(abs(ecartType([17, 25, 43]) - 13.3166) < 0.01)
assert(abs(ecartType([1, 2, 3, 4]) - 1.29099) < 0.01)
