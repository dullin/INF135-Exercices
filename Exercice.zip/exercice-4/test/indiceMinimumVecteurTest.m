[a, b] = indiceMinimumVecteur([34 67 12]);
assert(a == 12 && b == 3)
[a, b] = indiceMinimumVecteur([43 11 81]);
assert(a == 11 && b == 2)