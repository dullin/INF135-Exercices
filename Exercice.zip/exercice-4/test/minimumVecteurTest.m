assert(isequal(minimumVecteur([34, 65, 12]), 12))
assert(isequal(minimumVecteur([15, 15, 15]), 15))