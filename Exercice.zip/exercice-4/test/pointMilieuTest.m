assert(isequal(pointMilieu([1, 1], [3, 3]), [2, 2]))
assert(isequal(pointMilieu([5, 5], [7, 7]), [6, 6]))
