assert(produitCumulatif([3, 6, 12]) == 216)
assert(produitCumulatif([2, 2, 2]) == 8)