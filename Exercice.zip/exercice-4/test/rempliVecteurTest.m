assert(isequal(rempliVecteur(2, 12), [12, 12]))
assert(isequal(rempliVecteur(3, 7), [7, 7, 7]))
assert(isequal(rempliVecteur(1, 1), 1))
