assert(isequal(sousEnsembleVec([34, 23, 2, 75], 1, 2),[34, 23]))
assert(isequal(sousEnsembleVec([54, 23, 65, 23, 45, 87], 2, 4), [23, 65, 23]))