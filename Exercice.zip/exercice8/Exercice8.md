---
title: Exercice 8
---

Les prochaines questions traite des informations sur des joueurs de
hockey. Les joueurs sont regroupés par club. Pour chaque joueur, le
programme traite les informations suivantes :

-   nom
-   prénom
-   club
-   nombre de parties jouées
-   nombre de buts
-   nombre de passes
-   nombre de points
-   +/-

# Exercice 1
Écrivez une classe Joueur qui contient les propriétés précédentes.

# Exercice 2
Écrivez une fonction qui saisit le nombre de joueurs et saisit ensuite
les informations sur les joueurs et enregistre dans un tableau
d'enregistrement de joueurs ces informations. Elle retourne le tableau
contenant les joueurs.

# Exercice 3
Écrivez une fonction qui affiche toutes les informations du joueur reçu
en paramètre.

# Exercice 4
Écrivez une fonction qui retourne le meilleur joueur du tableau. Le
meilleur joueur est celui qui a le plus de points. En cas d'égalité,
elle retourne le dernier joueur rencontré.

# Exercice 5
Écrivez un classe Club qui contient les informations suivantes sont écrites :

-   Le nom du club
-   La somme des buts comptés par le club.
-   La somme des passes effectuées par le club.
-   La somme des points du club.

# Exercice 6
Écrivez une fonction qui affiche les informations concernant chacun des
clubs d'un tableau de joueurs. 

# Exercice 7
Écrivez un script qui lit au clavier les informations des joueurs et
les copie dans un tableau de joueurs. Il affiche ensuite toutes les
informations du meilleur joueur. Enfin, des informations sur chacun des
clubs sont affichées à l'écran.
