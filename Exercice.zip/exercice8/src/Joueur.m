classdef Joueur
    properties
        nom
        prenom
        club
        pj
        buts
        passes
        points
        pm
    end
    
    
end

