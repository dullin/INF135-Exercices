% Vide la fenêtre de commande, affiche le message "Allo monde!" avec un
% saut de ligne dans la fenêtre de commande.
% 
% Example:
%   ::
%
%       >> alloMonde
%         Allo monde!
%

% Vide la fenêtre de commande.
clc

% Affiche le message et on saute une ligne.
fprintf('Allo monde!\n')
