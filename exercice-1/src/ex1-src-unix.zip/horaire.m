% Affiche l'horaire suivant dans le fenêtre de commande: 
%
% Example:
%   ::
%
%       >> horaire
%       Horaire:
%       7h00 – déjeuner
%       12h00 – diner
%       17h00 – souper
%          
%

% Vide la fenêtre de commande.
clc

% Affiche l'horaire.
fprintf('Horaire:\n')
fprintf('7h00 - déjeuner\n')
fprintf('12h00 - diner\n')
fprintf('17h00 - souper\n')
