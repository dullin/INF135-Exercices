% Vide la fen�tre de commande, affiche le message "Allo monde!" avec un
% saut de ligne dans la fen�tre de commande.
% 
% Example:
%   ::
%
%       >> alloMonde
%         Allo monde!
%

% Vide la fen�tre de commande.
clc

% Affiche le message et on saute une ligne.
fprintf('Allo monde!\n')
