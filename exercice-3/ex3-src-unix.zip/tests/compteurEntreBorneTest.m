assert(compteurEntreBorne(4, 5) == 9)
assert(compteurEntreBorne(9, 12) == 42)