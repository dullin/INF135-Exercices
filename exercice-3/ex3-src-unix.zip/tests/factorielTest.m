assert(factoriel(5) == 120)
assert(abs(factoriel(20) - 2.4329e+18) < 1e13)