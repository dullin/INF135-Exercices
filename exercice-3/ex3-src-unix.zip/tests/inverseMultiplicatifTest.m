assert(abs(inverseMultiplicatif(4) - 0.25) < 0.001)
assert(abs(inverseMultiplicatif(25) - 0.04) < 0.001)