assert(nDiviseur(45) == 6)
assert(nDiviseur(3425) == 6)
assert(nDiviseur(3400) == 24)