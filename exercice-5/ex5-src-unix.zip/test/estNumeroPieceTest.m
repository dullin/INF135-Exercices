assert(estNumeroPiece('BRQ-245-21') == true)
assert(estNumeroPiece('allo') == false)
assert(estNumeroPiece('B2Q-245-21') == false)