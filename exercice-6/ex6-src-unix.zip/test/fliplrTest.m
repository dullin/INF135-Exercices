assert(isequal(fliplr([1 2 3; 4 5 6]), [3 2 1; 6 5 4]))
assert(isequal(fliplr([1 2; 3 4]), [2 1; 4 3]))