assert(isequal(flipud([1 2 3; 4 5 6]), [4 5 6; 1 2 3]))
assert(isequal(flipud([1 2; 3 4; 5 6]), [5 6; 3 4; 1 2]))