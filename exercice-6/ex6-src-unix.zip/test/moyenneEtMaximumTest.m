[moy, max] = moyenneEtMaximum([9, 10, 2, 10, 7]);
assert(abs(moy - 7.6) < 0.01)
assert(max == 10)