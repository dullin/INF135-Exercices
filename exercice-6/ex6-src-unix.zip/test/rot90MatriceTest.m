assert(isequal(rot90Matrice([1 2 3; 4 5 6]), ...
    [3     6
     2     5
     1     4]))
