assert(estMatriceIdentite([1 2; 3 4]) == false)
assert(estMatriceIdentite([1 0 0; 0 1 0; 0 0 1]) == true)
