classdef Club
    
    properties
        nom
        nbButs = 0
        nbPasses = 0
        nbPoints = 0
    end
    
end

